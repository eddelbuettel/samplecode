### R code from vignette source 'pkgEvignette.Rnw'

###################################################
### code chunk number 1: pkgEvignette.Rnw:23-25
###################################################
prettyVersion <- packageDescription("pkgEvignette")[["Version"]]
prettyDate <- format(Sys.Date(), "%B %e, %Y")


###################################################
### code chunk number 2: sample
###################################################
set.seed(123)
x <- cumsum(rnorm(100))
plot(x, type='l', main="A random walk")


